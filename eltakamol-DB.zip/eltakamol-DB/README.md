# eltakamol git commit --merge -eltakamol/eltakamul
# eltakamol git commit --allow-empty -m
# eltakamol git commit --allow-empty -m 'Trigger update'
# eltakamol git commit --allow-empty -m 'Trigger update'
# eltakamol git commit --allow-empty -m 
# eltakamol git commit --allow-empty -m "Commit message"
# eltakamol git commit --allow-empty -m 'Trigger update'; git push
# eltakamol git commit --allow-empty -m 'Trigger update'; git push
# eltakamol git commit --allow-empty -m 'Trigger update'; git push
